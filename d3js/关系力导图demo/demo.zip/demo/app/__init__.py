from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./novel.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)

class Novel(db.Model):
    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(128), index=True)
    author = db.Column(db.String(128), index=True)
    url = db.Column(db.String(128))
    source = db.Column(db.String(128), index=True)
    site = db.Column(db.String(32))
    novel_content = db.relationship('Content', backref='novel', lazy='dynamic')

    def __str__(self):
        return self.name

class Content(db.Model):
    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(128), index=True)
    url = db.Column(db.String(128))
    novel_id = db.Column(db.Integer, db.ForeignKey('novel.id'))


    def __str__(self):
        return self.name

def export2db(file_name):
    print(file_name)
    with open(file_name, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines:
            try:
                name = line.split(' ')[0].strip()
                author = line.split(' ')[1].strip()
                url = line.split(' ')[3].strip().replace('\n', '')
                source = line.split(' ')[2].strip()   
                site = url.split('.')[-2]
                print(name, site)
                result = Novel.query.filter_by(name=name, site=site).first()
                # print(result)
                if result is None:
                    novel = Novel(author=author, name=name, url=url, source=source, site=site)
                    db.session.add(novel)
                    db.session.commit()
                else:
                    print('数据已存在')
            except:
                pass


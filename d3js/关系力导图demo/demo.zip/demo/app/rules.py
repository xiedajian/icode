import lxml, requests
from lxml import etree
from  app import Novel, Content, db
from configparser import ConfigParser

config = ConfigParser()
config.read('app\\config.ini', encoding='utf-8')
print(config.sections())
site = config.get('defaults', 'site')


headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299',
}


Rules = {
    '88dus': '//div[@class="mulu"]//li',
    'xbiqiwu': '//div[@id="list"]//dd',
    'kxs7': '//div[@id="list"]//dd[position()>12]',
}

class get_content_list:
    def __init__(self):
        id = self.id 
        site = self.site

    def a88dus(id):    
        result = Content.query.filter_by(novel_id=id).first()
        if result:
            print('数据存在')
        else:
            novel = Novel.query.filter_by(id=id).first()
            r = requests.get(novel.url, headers=headers)
            html = etree.HTML(r.content)
            content_list = html.xpath(Rules.get(site))
            for content in content_list:
                url1 = content.xpath('a/@href')
                try:
                    content_url = novel.url + url1[0]
                    content_name = content.xpath('a/text()')[0]
                    print(content_name, '--->', content_url)
                    content = Content(name=content_name, url=content_url, novel_id=id)
                    db.session.add(content)
                    db.session.commit()
                except:
                    print('解析错误')

    def xbiqiwu(id):    
        result = Content.query.filter_by(novel_id=id).first()
        if result:
            print('数据存在')
        else:
            novel = Novel.query.filter_by(id=id).first()
            r = requests.get(novel.url, headers=headers)
            html = etree.HTML(r.content)
            content_list = html.xpath(Rules.get(site))
            site_domain = novel.url.split("/")[2]
            for content in content_list:
                url1 = content.xpath('a/@href')
                try:
                    content_url = "http://" + site_domain + url1[0]
                    content_name = content.xpath('a/text()')[0]
                    print(content_name, '--->', content_url)
                    content = Content(name=content_name, url=content_url, novel_id=id)
                    db.session.add(content)
                    db.session.commit()
                except:
                    print('解析错误')

    def kxs7(id):    
        result = Content.query.filter_by(novel_id=id).first()
        if result:
            print('数据存在')
        else:
            novel = Novel.query.filter_by(id=id).first()
            r = requests.get(novel.url, headers=headers)
            html = etree.HTML(r.content)
            content_list = html.xpath(Rules.get(site))
            site_domain = novel.url.split("/")[2]
            for content in content_list:
                url1 = content.xpath('a/@href')
                try:
                    content_url = "https://" + site_domain + url1[0]
                    content_name = content.xpath('a/text()')[0]
                    print(content_name, '--->', content_url)
                    content = Content(name=content_name, url=content_url, novel_id=id)
                    db.session.add(content)
                    db.session.commit()
                except:
                    print('解析错误')


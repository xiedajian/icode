from app import Novel, Content, db
import requests, time, os
from lxml.etree import HTML
from multiprocessing.dummy import Pool
from PIL import ImageGrab
import random, re

from selenium import webdriver
from selenium.webdriver.common.keys import Keys

# 导入配置文件
from configparser import ConfigParser

config = ConfigParser()
config.read('app\\config.ini', encoding='utf-8')
sleep_time = int(config.get('defaults', 'sleep_time'))
site = config.get('defaults', 'site')
get_novel_pic = config.getboolean('defaults', 'get_novel_pic')
novel_content_lenth = config.getint('defaults', 'novel_content_lenth')

def get_novel(id,site):
    """判断目录是否存在并创建"""
    base_path = os.path.abspath('.') + '\\novel_path' + '\\' + site
    if os.path.exists(base_path) is False:
        os.mkdir(base_path)
    # chrome_options = webdriver.ChromeOptions()
    # chrome_options.add_argument('--proxy-server={}'.format(ip))
    # chrome_options.add_extension('广告终结者3.1.4.crx')

    novel = Novel.query.filter_by(id=id).first()
    # chromedriver = "/usr/local/bin/chromedriver"

    chromedriver = os.path.abspath('.') + "\\2014-08-20_ChromePortable\App\Chrome\chromedriver.exe"
    driver = webdriver.Chrome(chromedriver)  # ,chrome_options=chrome_options)  #调用chrome浏览器
    # handles = driver.window_handles
    # driver.switch_to_window(handles[0])
    # time.sleep(15)
    # driver.get('http://www.hujuge.com//html/277/277645/23170440.shtml')
    # x小说详情页url
    novel_url = novel.url
    print(novel_url)
    driver.get(novel_url)
    driver.maximize_window()
    height = driver.find_element_by_xpath('/html/body').size['height']
    # print(height)
    # print('页面高度',driver.find_element_by_xpath('/html/body').size)
    cishu = height // 800 + 1
    for i in range(0, cishu):
        if get_novel_pic is True:
            pic = ImageGrab.grab()
            novel_title = re.sub('[\/::*?"<>|]', '-', novel.name).replace('.', '')
            # print(novel_title)

            novel_path = base_path + '\\' + novel_title
            # 第一次创建文件夹
            if os.path.exists(novel_path):
                pic = ImageGrab.grab()
                pic.save('{}\\{}-{}.png'.format(novel_path, novel_title, i))
                driver.execute_script("window.scrollBy(0,800)")
                time.sleep(sleep_time)
            else:
                os.mkdir(novel_path)
                pic = ImageGrab.grab()
                pic.save('{}\\{}-{}.png'.format(novel_path, novel_title, i))
                driver.execute_script("window.scrollBy(0,800)")
                time.sleep(sleep_time)
        else:
            time.sleep(sleep_time)
            driver.execute_script("window.scrollBy(0,800)")
    driver.quit()


# def get_content_menu(id):
#     novel = Novel.query.filter_by(id=id).first()
#     chromedriver = os.path.abspath('.') + "\\2014-08-20_ChromePortable\App\Chrome\chromedriver.exe"
#     driver = webdriver.Chrome(chromedriver)  # ,chrome_options=chrome_options)  #调用chrome浏览器
#     novel_title = re.sub('[\/::*?"<>|]', '-', novel.name).replace('.', '')
#     #获取文章目录页
#     driver.get(novel_content_url)
#     height=driver.find_element_by_xpath('/html/body').size['height']
#     cishu = height//800 + 1
#     for i in range(0,cishu):
#         pic = ImageGrab.grab()
#         novel_path = 'novel_path\\' + novel_title
#         #第一次创建文件夹
#         if os.path.exists(novel_path):
#             pic = ImageGrab.grab()
#             pic.save('{}\\{}-{}.jpg'.format(novel_path, novel_title + '章节目录' , i))
#             driver.execute_script("window.scrollBy(0,800)")
#         else:
#             os.mkdir(novel_path)
#             pic = ImageGrab.grab()
#             pic.save('{}\\{}-{}.jpg'.format(novel_path, novel_title + '章节目录', i ))
#             driver.execute_script("window.scrollBy(0,800)")
#     driver.quit()


def get_content(id, novel_content_lenth):
    """判断目录是否存在并创建"""
    base_path = os.path.abspath('.') + '\\novel_path' + '\\' + site
    if os.path.exists(base_path) is False:
        os.mkdir(base_path)
    # 获取小说每章节的信息
    novel = Novel.query.filter_by(id=id).first()
    base_path1 = base_path  + '\\' + novel.name
    if os.path.exists(base_path1) is False:
        os.mkdir(base_path1)
    chromedriver = os.path.abspath('.') + "\\2014-08-20_ChromePortable\App\Chrome\chromedriver.exe"
    print(novel.novel_content)
    driver = webdriver.Chrome(chromedriver)  # ,chrome_options=chrome_options)  #调用chrome浏览器
    novel_title = re.sub('[\/::*?"<>|]', '-', novel.name).replace('.', '')
    for content in novel.novel_content[:novel_content_lenth]:
        title_old = content.name.replace("[\'", '').replace("\']", '').replace('.', '').replace('\\u', '').replace(
            '\\t', '')
        novel_content_title = re.sub('[\/:*?"<>|]', '-', title_old)
        novel_conten_link = content.url
        print(novel_conten_link, novel_content_title)
        driver.get(novel_conten_link)
        driver.maximize_window()
        # time.sleep(random.choice(range(1,3)))
        # 下载小说内容

        height = driver.find_element_by_xpath('/html/body').size['height']
        cishu = height // 800 + 1
        for i in range(0, cishu):
            if get_novel_pic is True:
                pic = ImageGrab.grab()
                novel_content_path = base_path  + '\\' + novel_title + '\\' + novel_content_title
                # 第一次创建文件夹
                if os.path.exists(novel_content_path):
                    pic = ImageGrab.grab()
                    pic.save('{}\\{}-{}.png'.format(novel_content_path, novel_title + '章节目录', i))
                    driver.execute_script("window.scrollBy(0,800)")
                    time.sleep(sleep_time)
                else:
                    os.mkdir(novel_content_path)
                    pic = ImageGrab.grab()
                    pic.save('{}\\{}-{}.png'.format(novel_content_path, novel_title + '章节目录', i))
                    time.sleep(sleep_time)
                    driver.execute_script("window.scrollBy(0,800)")
                    text = driver.page_source
                    html = HTML(text)
                    txt = html.xpath('//text()')
                    novel_content_path = base_path  + '\\' + novel_title + '\\' + novel_content_title
                    for value in txt:
                        with open('{}/{}.txt'.format(novel_content_path, novel_content_title), 'a+', encoding='utf-8') as f:
                            f.write(value + '\n')
            else:
                time.sleep(sleep_time)
                driver.execute_script("window.scrollBy(0,800)")
    driver.quit()






def main():
    ip = '0.0.0.0'
    for i in range(1,5):
        get_novel(i)
        get_content(i)


if __name__ == '__main__':
    main()